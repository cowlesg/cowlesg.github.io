using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlipFlop : MonoBehaviour
{

    [SerializeField] bool red;
    [SerializeField] bool blue;

    // Start is called before the first frame update
    void Start()
    {
        if (red)
        {
            GameObject.Find("PlatformManager").GetComponent<SwapManager>().AddRed(gameObject);
        }
        else
        {
            GameObject.Find("PlatformManager").GetComponent<SwapManager>().AddBlue(gameObject);
        }
       
    }


    public void turnOn()
    {
        GetComponent<BoxCollider2D>().enabled = true;
        Color tmp = GetComponent<SpriteRenderer>().color;
        tmp.a = 1f;
        GetComponent<SpriteRenderer>().color = tmp;

    }

    public void turnOff()
    {
        GetComponent<BoxCollider2D>().enabled = false;
        Color tmp = GetComponent<SpriteRenderer>().color;
        tmp.a = 0.25f;
        GetComponent<SpriteRenderer>().color = tmp;
    }
}
