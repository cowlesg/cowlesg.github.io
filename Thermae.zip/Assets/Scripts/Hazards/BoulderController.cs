using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoulderController : HazardController
{

    public float torque = 10f;

    float initTorque;
    Vector2 origin;
    Rigidbody2D rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        origin = transform.position;
        initTorque = torque;
        StartCoroutine(SpawnBoulder(initTorque));
        //transform.localScale = new Vector3(.1f, .1f, .1f);    
    }

    void FixedUpdate()
    {
        rb.AddTorque(torque);
    }

    override public void ResetHazard()
    {
        rb.velocity = Vector2.zero;
        transform.position = origin;
        gameObject.SetActive(false);
    }

    public IEnumerator SpawnBoulder(float spawnerTorque)
    {
        // start small and turn off gravity
        rb.gravityScale = 0f;
        transform.rotation = Quaternion.identity;
        transform.position = origin;
        torque = 0f;

        float duration = 2f;
        float elapsedTime = 0f;
        Vector3 startScaleVector = new Vector3(.1f, .1f, .1f);
        Vector3 endScaleVector = new Vector3(.83f, .83f, .83f);
        transform.localScale = startScaleVector;
        while (elapsedTime < duration)
        {
            transform.localScale = Vector3.Lerp(startScaleVector, endScaleVector, elapsedTime / duration);
            elapsedTime += Time.deltaTime;
            yield return null;
        }
        Debug.Log("Boulder spawned!");
        //transform.localScale = endScaleVector;
        torque = spawnerTorque;
        rb.gravityScale = 1f;

    }
}
