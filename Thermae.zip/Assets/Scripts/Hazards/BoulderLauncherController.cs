using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoulderLauncherController : MonoBehaviour
{
    [SerializeField] float boulderTorque = 10f;
    [SerializeField] int numPooled = 10;
    [SerializeField] float launchInterval = 10f;

    List<GameObject> pooledBoulders = new List<GameObject>();
    GameObject boulderPrefab;
    // Start is called before the first frame update
    void Start()
    {
        boulderPrefab = Resources.Load<GameObject>("Prefabs/Boulder");
        for (int i = 0; i < numPooled; ++i)
        {
            GameObject tmp = Instantiate(boulderPrefab, transform);
            tmp.SetActive(false);
            pooledBoulders.Add(tmp);
        }
        StartCoroutine(LaunchBoulders());

    }

    private IEnumerator LaunchBoulders()
    {
        while (true)
        {
            GameObject newBoulder;
            foreach (GameObject b in pooledBoulders)
            {
                if (!b.activeInHierarchy)
                {
                    newBoulder = b;
                    newBoulder.SetActive(true);
                    yield return StartCoroutine(newBoulder.GetComponent<BoulderController>().SpawnBoulder(boulderTorque));
                    break;
                }
            }
            yield return new WaitForSeconds(launchInterval); // Wait for the launch interval.


        }
    }
}
