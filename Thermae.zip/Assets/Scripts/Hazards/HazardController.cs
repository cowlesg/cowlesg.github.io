using System.Collections;
using System.Collections.Generic;
using UnityEngine;

abstract public class HazardController : MonoBehaviour
{
    abstract public void ResetHazard();
}
