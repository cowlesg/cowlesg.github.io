using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpikeController : HazardController
{
    public Vector2 origin;

    Rigidbody2D rb;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }
    // Start is called before the first frame update
    void Start()
    {
        origin = transform.position;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        rb.velocity = Vector2.zero;
        transform.position = origin;
        gameObject.SetActive(false);


    }

    // added Stay() bc spike was tunneling through platforms due to speed
    private void OnCollisionStay2D(Collision2D collision)
    {
        rb.velocity = Vector2.zero;
        transform.position = origin;
        gameObject.SetActive(false);
    }

    override public void ResetHazard()
    {
        rb.velocity = Vector2.zero;
        transform.position = origin;
        gameObject.SetActive(false);    
    }

    public void SetVelocity(Vector2 newVelocity)
    {
        Debug.Log(rb);
        rb.velocity = new Vector2(newVelocity.x, newVelocity.y);
    }



}

