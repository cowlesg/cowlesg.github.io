using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealOnTouch : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            if (PlayerData.instance.GetHealth() < 3)
            {
                EventBus.Publish<HealEvent>(new HealEvent(10));
            }
            Destroy(gameObject);

        }
    }
}

public class HealEvent
{
    public int heal_amt = 1;
    public HealEvent(int _heal_amt) { heal_amt = _heal_amt; }
}
