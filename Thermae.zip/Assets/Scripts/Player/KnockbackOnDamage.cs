using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KnockbackOnDamage : MonoBehaviour
{

    [SerializeField] float knockbackForce;
    Rigidbody2D rb;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        
    }

    private void Knockback(Vector2 enemyPosition)
    {
        rb.velocity = new Vector2(0, rb.velocity.y);
        if (transform.position.x < enemyPosition.x)
        {
            rb.AddForce(Vector2.left * knockbackForce);
        } else
        {
            rb.AddForce(Vector2.right * knockbackForce);
        }
        StartCoroutine(pauseInput(0.5f));
        
    }

    private IEnumerator pauseInput(float pauseDuration)
    {
        GetComponent<PlayerController>().enabled = false;
        yield return new WaitForSeconds(pauseDuration);
        GetComponent<PlayerController>().enabled = true;

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Hazard")
        {
            Debug.Log("Spiked");
            Knockback(collision.gameObject.transform.position);
        }
    }
}
