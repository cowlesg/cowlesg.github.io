using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerData : MonoBehaviour
{
    public static PlayerData instance;

    private bool invincible;
    private int health = 3;

    Subscription<DamageEvent> damage_event_subscription;
    Subscription<HealEvent> heal_event_subscription;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Debug.Log("PlayerData already assigned to a loaded gameObeject");
            Destroy(gameObject);
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        damage_event_subscription = EventBus.Subscribe<DamageEvent>(_OnDamage);
        heal_event_subscription = EventBus.Subscribe<HealEvent>(_OnHeal);
    }
    
    public int GetHealth()
    {
        return health;
    }

    public bool IsInvincible()
    {
        return invincible;
    }

    public void SetInvincible(bool state) 
    {
        invincible = state;
    }

    void _OnDamage(DamageEvent e)
    {
        health--;
    }

    void _OnHeal(HealEvent e)
    {
        health++;
    }
    private void OnDestroy()
    {
        EventBus.Unsubscribe(damage_event_subscription);
        EventBus.Unsubscribe(heal_event_subscription);
    }
}
