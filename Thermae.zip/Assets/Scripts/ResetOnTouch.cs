using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResetOnTouch : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            collision.gameObject.transform.position = collision.gameObject.GetComponent<PlayerController>().respawnLocation;
            EventBus.Publish<DeathEvent>(new DeathEvent("You fell to your death..."));    
        }
        if (collision.gameObject.tag == "Hazard")
        {
            collision.gameObject.GetComponent<HazardController>().ResetHazard();
        }
    }
}

public class DeathEvent
{
    public string death_subtext = "";
    public DeathEvent(string _death_subtext) { death_subtext = _death_subtext; }

}
