using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReverseTorqueOnTouch : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        BoulderController boulderTorque = collision.gameObject.GetComponent<BoulderController>();
        if (boulderTorque != null)
        {
            boulderTorque.torque *= -1;
        }
    }
}
