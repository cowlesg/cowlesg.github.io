﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SinWaveMovement : MonoBehaviour
{
    float offset;
    private void Start()
    {
        offset = transform.position.y;
    }
    void Update()
    {
        transform.position = new Vector2(transform.position.x, offset + Mathf.Sin(Time.time)*0.5f);
    }
}
