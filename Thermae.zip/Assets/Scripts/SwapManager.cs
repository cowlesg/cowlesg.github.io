using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwapManager : MonoBehaviour
{
    private List<GameObject> redPlatforms = new List<GameObject>();
    private List<GameObject> bluePlatforms = new List<GameObject>();
    private string currentActive = "Red";

    public void AddRed(GameObject redPlatform)
    {
        redPlatforms.Add(redPlatform);
    }

    public void AddBlue(GameObject bluePlatform)
    {
        bluePlatforms.Add(bluePlatform);
    }

    public void Swap()
    {
        if (currentActive == "Red")
        {
            currentActive = "Blue";
            foreach (GameObject platform in redPlatforms)
            {
                platform.GetComponent<FlipFlop>().turnOff();
            }
            foreach (GameObject platform in bluePlatforms)
            {
                platform.GetComponent<FlipFlop>().turnOn();
            }
        }
        else
        {
            currentActive = "Red";
            foreach (GameObject platform in bluePlatforms)
            {
                platform.GetComponent<FlipFlop>().turnOff();
            }
            foreach (GameObject platform in redPlatforms)
            {
                platform.GetComponent<FlipFlop>().turnOn();
            }
        }

    }
}
